<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E-Commerce API</title>
</head>
<body>
    <h1>E-Commerce API</h1>
    <p>API Laravel fonctionnelle</p>
</body>
</html> 